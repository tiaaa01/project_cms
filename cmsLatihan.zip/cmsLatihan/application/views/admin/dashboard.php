<h1>Selamat datang di halaman dashboard</h1>
<?= $this->session->userdata('nama'); ?>