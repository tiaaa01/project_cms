<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class craousel extends CI_Controller {
    public function __construct(){
        parent::__construct();
		if($this->session->userdata('level')==NULL){
			redirect('auth');
		}
    }
	public function index(){
        $this->db->from('craousel');
        $craousel = $this->db->get()->result_array();
        $data = array(
            'judul_halaman' => 'Halaman craousel',
            'craousel' => $craousel,
        );
        $this->template->load('template_admin', 'admin/craousel_index', $data);
    }
        
        
	public function simpan(){
        $namafoto = date('YamdHis').'.jpg';
        $config['upload_path']          = 'assets/upload/craousel';
        $config['max_size'] = 500 * 1024; //3 * 1024 * 1024; //3mb; 0=unlimited
        $config['file_name']            = $namafoto;
        $config['allowed_types']        = '*';
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('foto')) {
            $this->session->set_flashdata('alert','
                <div class="alert alert-primary alert-dismissible" role="alert">
                        ukuran foto terlalu besar, upload ulang foto dengan ukuran yang kurang dari 500kb.
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>'
		    );
            redirect('admin/craousel');
        } elseif( ! $this->upload->do_upload('foto')){
            $error = array('error' => $this->upload->display_errors());
        }else{
            $data = array('upload_data' => $this->upload->data());
        }
		$data = array(
			'judul'  => $this->input->post('judul'),
            'foto'  => $namafoto,

		);
		$this->db->insert('craousel',$data);
		$this->session->set_flashdata('alert','
		<div class="alert alert-primary alert-dismissible" role="alert">
                berhasil menambahkan craousel.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>'
		);
		redirect('admin/craousel');

	}
	public function delete_data($id){
        $filename=FCPATH.'/assets/upload/craousel/'.$id;
        if(file_exists($filename)){
            unlink('./assets/upload/craousel/'.$id);
        }
		$where = array(
			'foto'   	=> $id
		);
		$this->db->delete('craousel',$where);
		$this->session->set_flashdata('alert','
		<div class="alert alert-primary alert-dismissible" role="alert">
                Berhasil menghapus kategori.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
		');
		redirect('admin/craousel');
	}

}
