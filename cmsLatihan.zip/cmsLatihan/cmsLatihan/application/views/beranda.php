SELAMAT DATANG <br>
<a href="<?= base_url('auth')?>">Klik Disini Untuk Login</a>